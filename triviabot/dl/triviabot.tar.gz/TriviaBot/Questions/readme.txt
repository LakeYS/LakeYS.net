This folder contains a sample question database. By default, the bot will use the online database instead.
See here for a guide on how to self-host and set up custom questions: http://lakeys.net/triviabot/install.html
